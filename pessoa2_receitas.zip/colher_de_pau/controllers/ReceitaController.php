<?php
require_once __DIR__ . "/../models/Receita.php";
require_once __DIR__ . "/../models/Categoria.php";

class ReceitaController
{
    private $model;
    private $categorias;

    public function __construct()
    {
        $this->model = new Receita();
        $this->categorias = new Categoria();
    }

    public function inicio()
    {
        return [
            "destaques" => $this->model->destaques(5),
            "populares" => $this->model->populares(4),
            "recentes" => $this->model->recentes(6, "Receita"),
            "tutoriais" => $this->model->recentes(3, "Tutorial"),
            "categorias" => $this->categorias->listar(),
        ];
    }

    public function filtrosDaUrl()
    {
        $filtros = [
            "busca" => trim((string) ($_GET["busca"] ?? "")),
            "categoria" => inteiro_get("categoria"),
            "tipo" => $_GET["tipo"] ?? "",
            "dificuldade" => $_GET["dificuldade"] ?? "",
            "ordem" => $_GET["ordem"] ?? "recentes",
        ];
        if (!in_array($filtros["tipo"], Receita::TIPOS, true)) {
            $filtros["tipo"] = "";
        }
        if (!in_array($filtros["dificuldade"], Receita::DIFICULDADES, true)) {
            $filtros["dificuldade"] = "";
        }
        if (!isset(Receita::ORDENS[$filtros["ordem"]])) {
            $filtros["ordem"] = "recentes";
        }
        $filtros["busca"] = mb_substr($filtros["busca"], 0, 80);
        return $filtros;
    }

    public function catalogo()
    {
        $filtros = $this->filtrosDaUrl();
        return [
            "filtros" => $filtros,
            "receitas" => $this->model->listar($filtros),
            "categorias" => $this->categorias->listar(),
        ];
    }

    public function detalhe($id)
    {
        $receita = $this->model->buscarPorId($id);
        if (!$receita) {
            return null;
        }

        $this->model->registrarVisualizacao($id);
        $receita["visualizacoes"]++;

        $passos = array_values(array_filter(array_map("trim", preg_split("/\R/", $receita["modo_preparo"]))));

        return [
            "receita" => $receita,
            "ingredientes" => $this->model->ingredientes($id),
            "passos" => $passos,
            "relacionadas" => $this->model->relacionadas($receita["categoria_id"], $id),
        ];
    }

    public function gerenciar()
    {
        $filtros = $this->filtrosDaUrl();
        return [
            "filtros" => $filtros,
            "receitas" => $this->model->listar($filtros),
            "categorias" => $this->categorias->listar(),
        ];
    }

    public function formulario($id = 0)
    {
        $receita = null;
        $ingredientes = [];
        if ($id) {
            $receita = $this->model->buscarPorId($id);
            if (!$receita) {
                flash("erro", "Receita não encontrada.");
                redirecionar("gerenciar_receitas");
            }
            $ingredientes = $this->model->ingredientes($id);
        }
        return [
            "receita" => $receita,
            "ingredientes" => $ingredientes,
            "categorias" => $this->categorias->listar(),
        ];
    }

    private function lerFormulario(&$erros)
    {
        $dados = [
            "titulo" => texto_post("titulo"),
            "tipo" => texto_post("tipo"),
            "resumo" => texto_post("resumo"),
            "modo_preparo" => texto_post("modo_preparo"),
            "tempo_preparo" => filter_var($_POST["tempo_preparo"] ?? "", FILTER_VALIDATE_INT),
            "rendimento" => texto_post("rendimento"),
            "dificuldade" => texto_post("dificuldade"),
            "destaque" => isset($_POST["destaque"]) ? 1 : 0,
            "categoria_id" => filter_var($_POST["categoria_id"] ?? "", FILTER_VALIDATE_INT),
        ];

        $ingredientes = [];
        $quantidades = (array) ($_POST["ingrediente_quantidade"] ?? []);
        foreach ((array) ($_POST["ingrediente_descricao"] ?? []) as $i => $descricao) {
            $descricao = trim((string) $descricao);
            if ($descricao !== "") {
                $ingredientes[] = [
                    "quantidade" => mb_substr(trim((string) ($quantidades[$i] ?? "")), 0, 50),
                    "descricao" => mb_substr($descricao, 0, 150),
                ];
            }
        }

        if (mb_strlen($dados["titulo"]) < 3 || mb_strlen($dados["titulo"]) > 120) {
            $erros[] = "O título deve ter entre 3 e 120 caracteres.";
        }
        if (!in_array($dados["tipo"], Receita::TIPOS, true)) {
            $erros[] = "Escolha se é uma receita ou um tutorial.";
        }
        if ($dados["resumo"] === "" || mb_strlen($dados["resumo"]) > 255) {
            $erros[] = "Escreva um resumo de até 255 caracteres.";
        }
        if (mb_strlen($dados["modo_preparo"]) < 10) {
            $erros[] = "Descreva o modo de preparo (um passo por linha).";
        }
        // RN03 - tempo de preparo entre 1 e 1440 minutos
        if ($dados["tempo_preparo"] === false || $dados["tempo_preparo"] < 1 || $dados["tempo_preparo"] > 1440) {
            $erros[] = "O tempo de preparo deve ficar entre 1 e 1440 minutos.";
        }
        if ($dados["rendimento"] === "" || mb_strlen($dados["rendimento"]) > 50) {
            $erros[] = "Informe o rendimento (ex.: 4 porções).";
        }
        if (!in_array($dados["dificuldade"], Receita::DIFICULDADES, true)) {
            $erros[] = "Escolha a dificuldade.";
        }
        if (!$dados["categoria_id"] || !$this->categorias->buscarPorId($dados["categoria_id"])) {
            $erros[] = "Escolha uma categoria válida.";
        }
        // RN02 - toda receita precisa de pelo menos um ingrediente
        if (count($ingredientes) === 0) {
            $erros[] = "Adicione pelo menos um ingrediente ou item necessário.";
        }

        return [$dados, $ingredientes];
    }

    private function voltarComErros($erros, $acao, $params = [])
    {
        guardar_antigo($_POST);
        flash("erro", implode(" ", $erros));
        redirecionar($acao, $params);
    }

    public function salvar()
    {
        $erros = [];
        [$dados, $ingredientes] = $this->lerFormulario($erros);

        if ($erros) {
            $this->voltarComErros($erros, "cadastrar_receita");
        }

        $erroUpload = "";
        $imagem = salvar_upload($_FILES["imagem"] ?? null, $erroUpload);
        if ($imagem === false) {
            $this->voltarComErros([$erroUpload], "cadastrar_receita");
        }

        $dados["imagem"] = $imagem;
        $dados["usuario_id"] = usuario_logado()["id"];
        $id = $this->model->cadastrar($dados, $ingredientes);

        limpar_antigo();
        flash("sucesso", $dados["tipo"] . " \"" . $dados["titulo"] . "\" publicada com sucesso.");
        redirecionar("receita", ["id" => $id]);
    }

    public function atualizar($id)
    {
        $atual = $this->model->buscarPorId($id);
        if (!$atual) {
            flash("erro", "Receita não encontrada.");
            redirecionar("gerenciar_receitas");
        }

        $erros = [];
        [$dados, $ingredientes] = $this->lerFormulario($erros);
        if ($erros) {
            $this->voltarComErros($erros, "editar_receita", ["id" => $id]);
        }

        $erroUpload = "";
        $nova = salvar_upload($_FILES["imagem"] ?? null, $erroUpload);
        if ($nova === false) {
            $this->voltarComErros([$erroUpload], "editar_receita", ["id" => $id]);
        }

        $dados["imagem"] = $atual["imagem"];
        if ($nova || isset($_POST["remover_imagem"])) {
            remover_upload($atual["imagem"]);
            $dados["imagem"] = $nova ?: null;
        }

        $this->model->editar($id, $dados, $ingredientes);
        limpar_antigo();
        flash("sucesso", "Alterações salvas.");
        redirecionar("receita", ["id" => $id]);
    }

    public function excluir($id)
    {
        $receita = $this->model->buscarPorId($id);

        // RN10 - confere antes; o Model garante a regra de novo
        if ($receita && $this->model->vinculadaAPedido($id)) {
            flash("erro", "\"" . $receita["titulo"] . "\" atende a um pedido de cliente e não pode ser excluída. Você pode editá-la.");
            redirecionar("gerenciar_receitas");
        }

        if ($receita && $this->model->excluir($id)) {
            remover_upload($receita["imagem"]);
            flash("sucesso", "\"" . $receita["titulo"] . "\" foi excluída.");
        } else {
            flash("erro", "Não foi possível excluir: a receita não existe mais.");
        }
        redirecionar("gerenciar_receitas");
    }
}
