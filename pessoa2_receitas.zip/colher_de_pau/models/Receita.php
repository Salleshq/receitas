<?php
require_once __DIR__ . "/../config/conexao.php";
require_once __DIR__ . "/Ingrediente.php";

class Receita
{
    const TIPOS = ["Receita", "Tutorial"];
    const DIFICULDADES = ["Fácil", "Média", "Difícil"];
    const ORDENS = [
        "recentes" => "r.criado_em DESC, r.id DESC",
        "populares" => "r.visualizacoes DESC, r.id DESC",
        "rapidas" => "r.tempo_preparo ASC, r.id DESC",
        "az" => "r.titulo ASC",
    ];

    private $db;

    private $select = "SELECT r.*, c.nome AS categoria, c.ilustracao, u.nome AS autor
                       FROM receitas r
                       INNER JOIN categorias c ON c.id = r.categoria_id
                       INNER JOIN usuarios u ON u.id = r.usuario_id";

    public function __construct()
    {
        $this->db = conectar();
    }

    public function listar($filtros = [], $limite = 0)
    {
        $sql = $this->select . " WHERE 1 = 1";
        $parametros = [];

        if (!empty($filtros["busca"])) {
            // busca no título, no resumo e na lista de ingredientes
            $sql .= " AND (r.titulo LIKE ? OR r.resumo LIKE ?
                      OR EXISTS (SELECT 1 FROM ingredientes i WHERE i.receita_id = r.id AND i.descricao LIKE ?))";
            $termo = "%" . $filtros["busca"] . "%";
            array_push($parametros, $termo, $termo, $termo);
        }
        if (!empty($filtros["categoria"])) {
            $sql .= " AND r.categoria_id = ?";
            $parametros[] = (int) $filtros["categoria"];
        }
        if (!empty($filtros["tipo"])) {
            $sql .= " AND r.tipo = ?";
            $parametros[] = $filtros["tipo"];
        }
        if (!empty($filtros["dificuldade"])) {
            $sql .= " AND r.dificuldade = ?";
            $parametros[] = $filtros["dificuldade"];
        }
        if (!empty($filtros["destaque"])) {
            $sql .= " AND r.destaque = 1";
        }

        $sql .= " ORDER BY " . (self::ORDENS[$filtros["ordem"] ?? ""] ?? self::ORDENS["recentes"]);
        if ($limite > 0) {
            $sql .= " LIMIT " . (int) $limite;
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($parametros);
        return $stmt->fetchAll();
    }

    public function destaques($limite)
    {
        return $this->listar(["destaque" => 1, "ordem" => "recentes"], $limite);
    }

    public function populares($limite)
    {
        return $this->listar(["ordem" => "populares"], $limite);
    }

    public function recentes($limite, $tipo = "")
    {
        return $this->listar(["tipo" => $tipo, "ordem" => "recentes"], $limite);
    }

    public function buscarPorId($id)
    {
        $stmt = $this->db->prepare($this->select . " WHERE r.id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function ingredientes($id)
    {
        return (new Ingrediente())->listarPorReceita($id);
    }

    public function relacionadas($categoriaId, $ignorarId, $limite = 3)
    {
        $stmt = $this->db->prepare(
            $this->select . " WHERE r.categoria_id = ? AND r.id <> ? ORDER BY r.visualizacoes DESC LIMIT " . (int) $limite
        );
        $stmt->execute([$categoriaId, $ignorarId]);
        return $stmt->fetchAll();
    }

    public function cadastrar($dados, $ingredientes)
    {
        $this->db->beginTransaction();
        try {
            $sql = "INSERT INTO receitas
                    (titulo, tipo, resumo, modo_preparo, tempo_preparo, rendimento,
                     dificuldade, imagem, destaque, categoria_id, usuario_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $dados["titulo"], $dados["tipo"], $dados["resumo"], $dados["modo_preparo"],
                $dados["tempo_preparo"], $dados["rendimento"], $dados["dificuldade"],
                $dados["imagem"], $dados["destaque"], $dados["categoria_id"], $dados["usuario_id"],
            ]);
            $id = (int) $this->db->lastInsertId();

            (new Ingrediente())->substituir($id, $ingredientes);
            $this->db->commit();
            return $id;
        } catch (PDOException $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function editar($id, $dados, $ingredientes)
    {
        $this->db->beginTransaction();
        try {
            $sql = "UPDATE receitas SET
                    titulo = ?, tipo = ?, resumo = ?, modo_preparo = ?, tempo_preparo = ?,
                    rendimento = ?, dificuldade = ?, imagem = ?, destaque = ?, categoria_id = ?
                    WHERE id = ?";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $dados["titulo"], $dados["tipo"], $dados["resumo"], $dados["modo_preparo"],
                $dados["tempo_preparo"], $dados["rendimento"], $dados["dificuldade"],
                $dados["imagem"], $dados["destaque"], $dados["categoria_id"], $id,
            ]);

            (new Ingrediente())->substituir($id, $ingredientes);
            $this->db->commit();
            return true;
        } catch (PDOException $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function vinculadaAPedido($id)
    {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM pedidos WHERE receita_id = ?");
        $stmt->execute([$id]);
        return $stmt->fetchColumn() > 0;
    }

    public function excluir($id)
    {
        // RN10 - receita que atendeu um pedido não pode ser excluída
        if ($this->vinculadaAPedido($id)) {
            return false;
        }
        $stmt = $this->db->prepare("DELETE FROM receitas WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->rowCount() > 0;
    }

    public function registrarVisualizacao($id)
    {
        // RN11 - o contador é calculado pelo sistema
        $stmt = $this->db->prepare("UPDATE receitas SET visualizacoes = visualizacoes + 1 WHERE id = ?");
        $stmt->execute([$id]);
    }

    public function contar()
    {
        return (int) $this->db->query("SELECT COUNT(*) FROM receitas")->fetchColumn();
    }

    public function listarTitulos()
    {
        return $this->db->query("SELECT id, titulo, tipo FROM receitas ORDER BY titulo")->fetchAll();
    }
}
