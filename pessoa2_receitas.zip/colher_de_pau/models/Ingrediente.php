<?php
require_once __DIR__ . "/../config/conexao.php";

class Ingrediente
{
    private $db;

    public function __construct()
    {
        $this->db = conectar();
    }

    public function listarPorReceita($receitaId)
    {
        $stmt = $this->db->prepare("SELECT * FROM ingredientes WHERE receita_id = ? ORDER BY ordem, id");
        $stmt->execute([$receitaId]);
        return $stmt->fetchAll();
    }

    public function substituir($receitaId, $ingredientes)
    {
        $stmt = $this->db->prepare("DELETE FROM ingredientes WHERE receita_id = ?");
        $stmt->execute([$receitaId]);

        $stmt = $this->db->prepare("INSERT INTO ingredientes (receita_id, quantidade, descricao, ordem) VALUES (?, ?, ?, ?)");
        foreach (array_values($ingredientes) as $ordem => $item) {
            $stmt->execute([$receitaId, $item["quantidade"], $item["descricao"], $ordem + 1]);
        }
    }
}
