<?php
$filtros = $dados["filtros"];
$receitas = $dados["receitas"];

$categoriaAtual = null;
foreach ($dados["categorias"] as $c) {
    if ((int) $c["id"] === (int) $filtros["categoria"]) {
        $categoriaAtual = $c;
    }
}

$titulo = $categoriaAtual["nome"] ?? ($filtros["tipo"] === "Tutorial" ? "Tutoriais" : "Receitas");
$pagina = $filtros["tipo"] === "Tutorial" ? "tutoriais" : "receitas";
$temFiltro = $filtros["busca"] || $filtros["categoria"] || $filtros["tipo"] || $filtros["dificuldade"];

$parametros = array_filter([
    "busca" => $filtros["busca"],
    "tipo" => $filtros["tipo"],
    "dificuldade" => $filtros["dificuldade"],
    "ordem" => $filtros["ordem"] !== "recentes" ? $filtros["ordem"] : "",
]);

require __DIR__ . "/../partials/topo.php";
?>

<div class="container">
    <header class="cabeca-pagina">
        <h1><?= e($titulo) ?></h1>
        <p>
            <?php if ($filtros["busca"]) { ?>
                Resultados para “<?= e($filtros["busca"]) ?>”.
            <?php } elseif ($categoriaAtual) { ?>
                <?= e($categoriaAtual["descricao"]) ?>
            <?php } else { ?>
                Busque pelo nome do prato ou por um ingrediente que você tem em casa.
            <?php } ?>
        </p>
    </header>

    <div class="trilha-categorias" style="margin-top: 24px">
        <a href="<?= url("receitas", $parametros) ?>" class="<?= !$filtros["categoria"] ? "ativo" : "" ?>">
            <span class="circulo circulo--todas">&amp;</span>
            Todas
        </a>
        <?php foreach ($dados["categorias"] as $categoria) { ?>
            <a href="<?= url("receitas", $parametros + ["categoria" => $categoria["id"]]) ?>"
               class="<?= (int) $filtros["categoria"] === (int) $categoria["id"] ? "ativo" : "" ?>">
                <span class="circulo"><img src="assets/img/ilustracoes/<?= e($categoria["ilustracao"]) ?>.svg" alt=""></span>
                <?= e($categoria["nome"]) ?>
            </a>
        <?php } ?>
    </div>

    <form class="filtros" action="index.php" method="GET">
        <input type="hidden" name="acao" value="receitas">
        <?php if ($filtros["categoria"]) { ?>
            <input type="hidden" name="categoria" value="<?= (int) $filtros["categoria"] ?>">
        <?php } ?>

        <div class="campo">
            <label for="f-busca">Buscar</label>
            <input type="search" id="f-busca" name="busca" maxlength="80" placeholder="Ex.: frango, chocolate, arroz"
                   value="<?= e($filtros["busca"]) ?>">
        </div>
        <div class="campo">
            <label for="f-tipo">Tipo</label>
            <select id="f-tipo" name="tipo">
                <option value="">Receitas e tutoriais</option>
                <?php foreach (Receita::TIPOS as $tipo) { ?>
                    <option value="<?= $tipo ?>" <?= $filtros["tipo"] === $tipo ? "selected" : "" ?>><?= $tipo === "Receita" ? "Só receitas" : "Só tutoriais" ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="campo">
            <label for="f-dificuldade">Dificuldade</label>
            <select id="f-dificuldade" name="dificuldade">
                <option value="">Qualquer</option>
                <?php foreach (Receita::DIFICULDADES as $nivel) { ?>
                    <option value="<?= $nivel ?>" <?= $filtros["dificuldade"] === $nivel ? "selected" : "" ?>><?= $nivel ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="campo">
            <label for="f-ordem">Ordenar por</label>
            <select id="f-ordem" name="ordem">
                <option value="recentes" <?= $filtros["ordem"] === "recentes" ? "selected" : "" ?>>Mais recentes</option>
                <option value="populares" <?= $filtros["ordem"] === "populares" ? "selected" : "" ?>>Mais vistas</option>
                <option value="rapidas" <?= $filtros["ordem"] === "rapidas" ? "selected" : "" ?>>Mais rápidas</option>
                <option value="az" <?= $filtros["ordem"] === "az" ? "selected" : "" ?>>Nome (A–Z)</option>
            </select>
        </div>
        <div class="filtros__acoes">
            <button type="submit" class="botao"><?= icone("busca") ?> Filtrar</button>
            <?php if ($temFiltro) { ?>
                <a class="botao botao--secundario" href="<?= url("receitas") ?>">Limpar</a>
            <?php } ?>
        </div>
    </form>

    <p class="contagem">
        <?= count($receitas) ?> <?= count($receitas) === 1 ? "resultado" : "resultados" ?>
    </p>

    <?php if ($receitas) { ?>
        <div class="grade" style="margin-bottom: 64px">
            <?php foreach ($receitas as $receita) { require __DIR__ . "/../partials/card_receita.php"; } ?>
        </div>
    <?php } else { ?>
        <div class="vazio" style="margin-bottom: 64px">
            <img src="assets/img/ilustracoes/generico.svg" alt="">
            <h2>Nada por aqui ainda</h2>
            <p>Não encontramos receitas com esses filtros. Tente outra palavra ou peça essa receita para a equipe.</p>
            <div class="acoes" style="justify-content: center">
                <a class="botao botao--secundario" href="<?= url("receitas") ?>">Ver todas</a>
                <a class="botao" href="<?= url(usuario_logado() ? "novo_pedido" : "login") ?>">Pedir esta receita</a>
            </div>
        </div>
    <?php } ?>
</div>

<?php require __DIR__ . "/../partials/rodape.php"; ?>
