<?php
$receita = $dados["receita"];
$ehTutorial = $receita["tipo"] === "Tutorial";
$titulo = $receita["titulo"];
$pagina = $ehTutorial ? "tutoriais" : "receitas";
require __DIR__ . "/../partials/topo.php";
?>

<div class="container">
    <ol class="migalhas">
        <li><a href="<?= url("inicio") ?>">Início</a></li>
        <li><a href="<?= url("receitas", ["tipo" => $receita["tipo"]]) ?>"><?= $ehTutorial ? "Tutoriais" : "Receitas" ?></a></li>
        <li><a href="<?= url("receitas", ["categoria" => $receita["categoria_id"]]) ?>"><?= e($receita["categoria"]) ?></a></li>
    </ol>

    <section class="receita-topo">
        <div class="receita-topo__imagem">
            <img src="<?= e(imagem_receita($receita)) ?>" alt="<?= e($receita["titulo"]) ?>">
        </div>
        <div>
            <div class="selos">
                <span class="selo"><?= e($receita["tipo"]) ?></span>
                <span class="selo selo--claro"><?= e($receita["categoria"]) ?></span>
            </div>
            <h1><?= e($receita["titulo"]) ?></h1>
            <p class="receita-topo__resumo"><?= e($receita["resumo"]) ?></p>

            <div class="fichas">
                <div class="ficha"><?= icone("relogio") ?><strong><?= formatar_tempo($receita["tempo_preparo"]) ?></strong><small>Tempo</small></div>
                <div class="ficha"><?= icone("porcao") ?><strong><?= e($receita["rendimento"]) ?></strong><small>Rende</small></div>
                <div class="ficha"><?= icone("nivel") ?><strong><?= e($receita["dificuldade"]) ?></strong><small>Nível</small></div>
                <div class="ficha"><?= icone("olho") ?><strong><?= (int) $receita["visualizacoes"] ?></strong><small>Visitas</small></div>
            </div>

            <div class="acoes">
                <button type="button" class="botao botao--secundario" data-imprimir><?= icone("impressora") ?> Imprimir</button>
                <?php if (eh_admin()) { ?>
                    <a class="botao" href="<?= url("editar_receita", ["id" => $receita["id"]]) ?>"><?= icone("lapis") ?> Editar</a>
                <?php } ?>
            </div>
            <p class="texto-suave" style="margin-top: 16px">
                Publicado em <?= formatar_data($receita["criado_em"]) ?> por <?= e($receita["autor"]) ?>
            </p>
        </div>
    </section>

    <section class="receita-corpo">
        <aside class="caixa ingredientes">
            <h2><?= $ehTutorial ? "O que você vai precisar" : "Ingredientes" ?></h2>
            <small>Marque o que já separou.</small>
            <ul class="lista-check">
                <?php foreach ($dados["ingredientes"] as $i => $item) { ?>
                    <li>
                        <label>
                            <input type="checkbox" aria-label="Separado">
                            <span>
                                <?php if ($item["quantidade"] !== "" && $item["quantidade"] !== null) { ?>
                                    <b><?= e($item["quantidade"]) ?></b>
                                <?php } ?>
                                <?= e($item["descricao"]) ?>
                            </span>
                        </label>
                    </li>
                <?php } ?>
            </ul>
        </aside>

        <div class="caixa">
            <h2><?= $ehTutorial ? "Passo a passo" : "Modo de preparo" ?></h2>
            <ol class="passos">
                <?php foreach ($dados["passos"] as $passo) { ?>
                    <li><p><?= e($passo) ?></p></li>
                <?php } ?>
            </ol>
        </div>
    </section>
</div>

<?php if ($dados["relacionadas"]) { ?>
<section class="secao secao--bege receitas-relacionadas">
    <div class="container">
        <div class="secao__cabeca">
            <div>
                <h2>Mais de <?= e($receita["categoria"]) ?></h2>
            </div>
            <a class="link-seta" href="<?= url("receitas", ["categoria" => $receita["categoria_id"]]) ?>">Ver categoria <?= icone("seta") ?></a>
        </div>
        <div class="grade">
            <?php foreach ($dados["relacionadas"] as $receita) { require __DIR__ . "/../partials/card_receita.php"; } ?>
        </div>
    </div>
</section>
<?php } ?>

<?php require __DIR__ . "/../partials/rodape.php"; ?>
