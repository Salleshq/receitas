<?php
$receita = $dados["receita"];
$temAntigo = isset($_SESSION["antigo"]);
$valor = fn($campo, $padrao = "") => antigo($campo, $receita[$campo] ?? $padrao);

if ($temAntigo) {
    $linhas = [];
    foreach ((array) antigo("ingrediente_descricao", []) as $i => $descricao) {
        $linhas[] = ["quantidade" => antigo("ingrediente_quantidade", [])[$i] ?? "", "descricao" => $descricao];
    }
} else {
    $linhas = $dados["ingredientes"];
}
if (!$linhas) {
    $linhas = array_fill(0, 3, ["quantidade" => "", "descricao" => ""]);
}

$destaque = $temAntigo ? antigo("destaque", false) !== false : !empty($receita["destaque"]);
?>
<form class="caixa" method="POST" action="<?= e($acaoFormulario) ?>" enctype="multipart/form-data">
    <?= csrf_campo() ?>

    <div class="linha-campos">
        <div class="campo">
            <label for="titulo">Título *</label>
            <input type="text" id="titulo" name="titulo" required minlength="3" maxlength="120" value="<?= e($valor("titulo")) ?>">
        </div>
        <div class="campo">
            <label for="categoria_id">Categoria *</label>
            <select id="categoria_id" name="categoria_id" required>
                <option value="">Escolha…</option>
                <?php foreach ($dados["categorias"] as $categoria) { ?>
                    <option value="<?= $categoria["id"] ?>" <?= (int) $valor("categoria_id") === (int) $categoria["id"] ? "selected" : "" ?>><?= e($categoria["nome"]) ?></option>
                <?php } ?>
            </select>
        </div>
    </div>

    <div class="campo">
        <label for="resumo">Resumo *</label>
        <input type="text" id="resumo" name="resumo" required maxlength="255" value="<?= e($valor("resumo")) ?>">
        <small>Uma frase que aparece no card. Até 255 caracteres.</small>
    </div>

    <div class="linha-campos linha-campos--3">
        <div class="campo">
            <label for="tipo">Tipo *</label>
            <select id="tipo" name="tipo" required>
                <?php foreach (Receita::TIPOS as $tipo) { ?>
                    <option value="<?= $tipo ?>" <?= $valor("tipo", "Receita") === $tipo ? "selected" : "" ?>><?= $tipo ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="campo">
            <label for="dificuldade">Dificuldade *</label>
            <select id="dificuldade" name="dificuldade" required>
                <?php foreach (Receita::DIFICULDADES as $nivel) { ?>
                    <option value="<?= $nivel ?>" <?= $valor("dificuldade", "Fácil") === $nivel ? "selected" : "" ?>><?= $nivel ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="campo">
            <label for="tempo_preparo">Tempo de preparo (min) *</label>
            <input type="number" id="tempo_preparo" name="tempo_preparo" required min="1" max="1440" step="1" value="<?= e($valor("tempo_preparo")) ?>">
        </div>
    </div>

    <div class="linha-campos">
        <div class="campo">
            <label for="rendimento">Rendimento *</label>
            <input type="text" id="rendimento" name="rendimento" required maxlength="50" placeholder="Ex.: 4 porções" value="<?= e($valor("rendimento")) ?>">
        </div>
        <div class="campo" style="justify-content: flex-end">
            <label class="checkbox">
                <input type="checkbox" name="destaque" value="1" <?= $destaque ? "checked" : "" ?>>
                Mostrar no carrossel de destaques da página inicial
            </label>
        </div>
    </div>

    <div class="form-secao">
        <h2>Lista de ingredientes</h2>
        <p>Em tutoriais, liste os itens e utensílios necessários. É obrigatório ter pelo menos um.</p>
        <div id="lista-ingredientes">
            <?php foreach ($linhas as $linha) { ?>
                <div class="linha-ingrediente">
                    <input type="text" name="ingrediente_quantidade[]" maxlength="50" placeholder="Quantidade" aria-label="Quantidade" value="<?= e($linha["quantidade"]) ?>">
                    <input type="text" name="ingrediente_descricao[]" maxlength="150" placeholder="Ingrediente" aria-label="Ingrediente" value="<?= e($linha["descricao"]) ?>">
                    <button type="button" class="botao-icone" data-remover-ingrediente aria-label="Remover ingrediente"><?= icone("lixo") ?></button>
                </div>
            <?php } ?>
        </div>
        <template id="modelo-ingrediente">
            <div class="linha-ingrediente">
                <input type="text" name="ingrediente_quantidade[]" maxlength="50" placeholder="Quantidade" aria-label="Quantidade">
                <input type="text" name="ingrediente_descricao[]" maxlength="150" placeholder="Ingrediente" aria-label="Ingrediente">
                <button type="button" class="botao-icone" data-remover-ingrediente aria-label="Remover ingrediente"><?= icone("lixo") ?></button>
            </div>
        </template>
        <button type="button" class="botao botao--secundario botao--pequeno" data-adicionar-ingrediente><?= icone("mais") ?> Adicionar ingrediente</button>
    </div>

    <div class="form-secao">
        <h2>Modo de preparo</h2>
        <div class="campo">
            <label for="modo_preparo">Passos *</label>
            <textarea id="modo_preparo" name="modo_preparo" required minlength="10" rows="9"><?= e($valor("modo_preparo")) ?></textarea>
            <small>Escreva um passo por linha. Cada linha vira um passo numerado na página.</small>
        </div>
    </div>

    <div class="form-secao">
        <h2>Foto</h2>
        <div class="campo">
            <div class="previa-imagem">
                <img id="previa" src="<?= e($receita ? imagem_receita($receita) : "assets/img/ilustracoes/generico.svg") ?>" alt="Prévia da imagem">
                <div>
                    <label for="imagem" class="rotulo">Enviar foto (opcional)</label>
                    <input type="file" id="imagem" name="imagem" accept="image/jpeg,image/png,image/webp" data-previa="previa">
                    <p class="dica">JPG, PNG ou WEBP com até 2 MB. Sem foto, usamos a ilustração da categoria.</p>
                    <?php if (!empty($receita["imagem"])) { ?>
                        <label class="checkbox"><input type="checkbox" name="remover_imagem" value="1"> Remover a foto atual</label>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>

    <div class="acoes" style="margin-top: 12px">
        <button type="submit" class="botao"><?= e($textoBotao) ?></button>
        <a class="botao botao--secundario" href="<?= url("gerenciar_receitas") ?>">Cancelar</a>
    </div>
</form>
