<?php
$titulo = "Nova receita";
$pagina = "conta";
$aba = "receitas";
$acaoFormulario = url("salvar_receita");
$textoBotao = "Publicar";
require __DIR__ . "/../partials/topo.php";
?>

<div class="container conta">
    <?php require __DIR__ . "/../partials/menu_conta.php"; ?>

    <div class="conta__cabeca">
        <div>
            <h1>Nova receita ou tutorial</h1>
            <p>Campos com * são obrigatórios.</p>
        </div>
    </div>

    <?php require __DIR__ . "/_form.php"; ?>
</div>

<?php require __DIR__ . "/../partials/rodape.php"; ?>
