<?php
$titulo = "Gerenciar receitas";
$pagina = "conta";
$aba = "receitas";
$filtros = $dados["filtros"];
require __DIR__ . "/../partials/topo.php";
?>

<div class="container conta">
    <?php require __DIR__ . "/../partials/menu_conta.php"; ?>

    <div class="conta__cabeca">
        <div>
            <h1>Receitas e tutoriais</h1>
            <p><?= count($dados["receitas"]) ?> publicação(ões) encontrada(s).</p>
        </div>
        <a class="botao" href="<?= url("cadastrar_receita") ?>"><?= icone("mais") ?> Nova receita</a>
    </div>

    <form class="busca-inline" action="index.php" method="GET">
        <input type="hidden" name="acao" value="gerenciar_receitas">
        <label class="sr-only" for="g-busca">Buscar</label>
        <input type="search" id="g-busca" name="busca" maxlength="80" placeholder="Buscar por título ou ingrediente" value="<?= e($filtros["busca"]) ?>">
        <label class="sr-only" for="g-categoria">Categoria</label>
        <select id="g-categoria" name="categoria">
            <option value="">Todas as categorias</option>
            <?php foreach ($dados["categorias"] as $categoria) { ?>
                <option value="<?= $categoria["id"] ?>" <?= (int) $filtros["categoria"] === (int) $categoria["id"] ? "selected" : "" ?>><?= e($categoria["nome"]) ?></option>
            <?php } ?>
        </select>
        <label class="sr-only" for="g-tipo">Tipo</label>
        <select id="g-tipo" name="tipo">
            <option value="">Receitas e tutoriais</option>
            <?php foreach (Receita::TIPOS as $tipo) { ?>
                <option value="<?= $tipo ?>" <?= $filtros["tipo"] === $tipo ? "selected" : "" ?>><?= $tipo ?></option>
            <?php } ?>
        </select>
        <button type="submit" class="botao botao--secundario"><?= icone("busca") ?> Filtrar</button>
    </form>

    <?php if ($dados["receitas"]) { ?>
        <div class="tabela-envoltorio">
            <table class="tabela-responsiva">
                <thead>
                    <tr>
                        <th>Receita</th>
                        <th>Categoria</th>
                        <th>Tipo</th>
                        <th>Tempo</th>
                        <th>Visitas</th>
                        <th>Destaque</th>
                        <th><span class="sr-only">Ações</span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($dados["receitas"] as $receita) { ?>
                        <tr>
                            <td class="td-principal">
                                <div class="celula-receita">
                                    <img src="<?= e(imagem_receita($receita)) ?>" alt="">
                                    <a href="<?= url("receita", ["id" => $receita["id"]]) ?>"><?= e($receita["titulo"]) ?></a>
                                </div>
                            </td>
                            <td data-rotulo="Categoria"><?= e($receita["categoria"]) ?></td>
                            <td data-rotulo="Tipo"><?= e($receita["tipo"]) ?></td>
                            <td data-rotulo="Tempo"><?= formatar_tempo($receita["tempo_preparo"]) ?></td>
                            <td data-rotulo="Visitas"><?= (int) $receita["visualizacoes"] ?></td>
                            <td data-rotulo="Destaque"><?= $receita["destaque"] ? '<span class="estrela">★ Sim</span>' : '<span class="texto-suave">Não</span>' ?></td>
                            <td class="td-acoes">
                                <div class="acoes">
                                    <a class="botao botao--secundario botao--pequeno" href="<?= url("editar_receita", ["id" => $receita["id"]]) ?>"><?= icone("lapis") ?> Editar</a>
                                    <form method="POST" action="<?= url("excluir_receita", ["id" => $receita["id"]]) ?>"
                                          data-confirmar="Excluir “<?= e($receita["titulo"]) ?>”? Os ingredientes também serão apagados.">
                                        <?= csrf_campo() ?>
                                        <button type="submit" class="botao botao--perigo botao--pequeno"><?= icone("lixo") ?> Excluir</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    <?php } else { ?>
        <div class="vazio">
            <p>Nenhuma receita encontrada com esses filtros.</p>
            <a class="botao" href="<?= url("cadastrar_receita") ?>">Cadastrar a primeira</a>
        </div>
    <?php } ?>
</div>

<?php require __DIR__ . "/../partials/rodape.php"; ?>
