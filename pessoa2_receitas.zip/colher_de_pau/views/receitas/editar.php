<?php
$titulo = "Editar receita";
$pagina = "conta";
$aba = "receitas";
$acaoFormulario = url("atualizar_receita", ["id" => $dados["receita"]["id"]]);
$textoBotao = "Salvar alterações";
require __DIR__ . "/../partials/topo.php";
?>

<div class="container conta">
    <?php require __DIR__ . "/../partials/menu_conta.php"; ?>

    <div class="conta__cabeca">
        <div>
            <h1>Editar “<?= e($dados["receita"]["titulo"]) ?>”</h1>
            <p>Campos com * são obrigatórios.</p>
        </div>
        <a class="botao botao--secundario" href="<?= url("receita", ["id" => $dados["receita"]["id"]]) ?>"><?= icone("olho") ?> Ver página</a>
    </div>

    <?php require __DIR__ . "/_form.php"; ?>
</div>

<?php require __DIR__ . "/../partials/rodape.php"; ?>
